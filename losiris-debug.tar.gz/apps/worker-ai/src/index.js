#!/usr/bin/env node

console.log('worker-ai placeholder');