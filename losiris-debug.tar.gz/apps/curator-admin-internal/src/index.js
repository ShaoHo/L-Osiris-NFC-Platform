#!/usr/bin/env node

console.log('curator-admin-internal placeholder');